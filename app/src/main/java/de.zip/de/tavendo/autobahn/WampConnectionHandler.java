package de.tavendo.autobahn;

public class WampConnectionHandler implements Wamp.ConnectionHandler {

	public void onOpen() {
		// TODO Auto-generated method stub
		
	}

	public void onClose(int code, String reason) {
		// TODO Auto-generated method stub
		
	}

}
